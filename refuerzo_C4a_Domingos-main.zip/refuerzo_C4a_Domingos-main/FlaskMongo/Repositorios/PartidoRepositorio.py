from Repositorios.InterfazRepositorio import InterfazRepositorio
from Modelos.Partido import Partido

class PartidoRepositorio(InterfazRepositorio[Partido]):
    pass