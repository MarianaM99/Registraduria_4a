from Repositorios.InterfazRepositorio import InterfazRepositorio
from Modelos.Mesa import Mesa

class MesaRepositorio(InterfazRepositorio[Mesa]):
    pass