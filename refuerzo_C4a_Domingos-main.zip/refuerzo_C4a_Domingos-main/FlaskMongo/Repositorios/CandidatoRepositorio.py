from Repositorios.InterfazRepositorio import InterfazRepositorio
from Modelos.Candidato import Candidato

class CandidatoRepositorio(InterfazRepositorio[Candidato]):
    pass