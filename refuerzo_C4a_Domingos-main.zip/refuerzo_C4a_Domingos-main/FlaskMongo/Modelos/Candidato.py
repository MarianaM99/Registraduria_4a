from Modelos.AbstractModel import AbstractModel
class Candidato(AbstractModel):
    pass