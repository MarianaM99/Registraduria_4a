from Modelos.AbstractModel import AbstractModel
class Partido(AbstractModel):
    pass