from Modelos.AbstractModel import AbstractModel
class Resultado(AbstractModel):
    pass