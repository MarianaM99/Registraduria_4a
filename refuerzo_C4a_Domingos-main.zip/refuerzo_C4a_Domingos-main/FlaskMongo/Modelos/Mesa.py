from Modelos.AbstractModel import AbstractModel
class Mesa(AbstractModel):
    pass